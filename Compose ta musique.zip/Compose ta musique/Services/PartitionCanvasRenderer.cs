using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ComposTaZik.Models;
using ComposTaZik.Services.Partition;
using ComposTaZik.ViewModels;


namespace ComposTaZik.Services
{
    public class PartitionCanvasRenderer
    {
        // Constantes de placement
      private const double TopOffset = 100;
private const double EspaceEntreSystemes = 150;
private const double LineSpacing = 10; // 10px par ligne
private const double NoteHeight = 10;
 private const double StepPx = 5; // Ecart visuel d'un degré
private void DessinerMesureAvecSuperposition(Canvas canvas, MesureVisualisee mesure, double xBase, double yBaseSol, double yBaseFa, bool isCleFa)
{
    var groupes = mesure.Notes
        .GroupBy(n => Math.Round(n.PositionX, 2)) // groupement par moment musical
        .OrderBy(g => g.Key);

    foreach (var groupe in groupes)
    {
        double xNote = xBase + groupe.Key;

        foreach (var note in groupe)
        {
            double yNote = ConvertirNoteEnYClassique(note, yBaseSol, yBaseFa);

            if (note.IsSilence)
                DessinerSilence(canvas, xNote, yNote, note.Duree, isCleFa);
            else
                DessinerNote(canvas, xNote, yNote, note);
        }
    }
}


public void DessinerPartitionDoublePortee(Canvas canvas, PartitionMusicale partition, bool isExport = false)

{
    canvas.Children.Clear();

    for (int i = 0; i < partition.Lignes.Count; i++)
    {
        var ligne = partition.Lignes[i];

        double yBaseSol = TopOffset + i * EspaceEntreSystemes - 10;
        double yBaseFa = yBaseSol + 60;

        DessinerPortee(canvas, yBaseSol);
        DessinerPortee(canvas, yBaseFa);
        DessinerSignatureRythmique(canvas, yBaseSol, yBaseFa);
        DessinerCleSol(canvas, yBaseSol - 17);
        DessinerCleFa(canvas, yBaseFa - 23);
        DessinerAccolade(canvas, yBaseSol, yBaseFa);

        for (int m = 0; m < ligne.MesuresSol.Count && m < ligne.MesuresFa.Count; m++)
        {
            var mesureSol = ligne.MesuresSol[m];
            var mesureFa = ligne.MesuresFa[m];

            double xMesureSol = mesureSol.Notes.FirstOrDefault()?.PositionX ?? (60 + m * 150);
            double xMesureFa = mesureFa.Notes.FirstOrDefault()?.PositionX ?? (60 + m * 150);

            double xBarre = Math.Max(xMesureSol, xMesureFa);

            if (m > 0)
            {
                DessinerBarreDeMesure(canvas, xBarre, yBaseSol);
                DessinerBarreDeMesure(canvas, xBarre, yBaseFa);
            }

            foreach (var note in mesureSol.Notes)
            {
                double yNote = ConvertirNoteEnYClassique(note, yBaseSol, yBaseFa);
                if (note.IsSilence)
                    DessinerSilence(canvas, note.PositionX, yNote, note.Duree, false);
                else
                    DessinerNote(canvas, note.PositionX, yNote, note);
            }

            foreach (var note in mesureFa.Notes)
            {
                double yNote = ConvertirNoteEnYClassique(note, yBaseSol, yBaseFa);
                if (note.IsSilence)
                    DessinerSilence(canvas, note.PositionX, yNote, note.Duree, true);
                else
                    DessinerNote(canvas, note.PositionX, yNote, note);
            }
        }
        
    }

 canvas.Width = 700; // ou 640, ou une valeur fixe que tu choisis
canvas.Height = TopOffset + partition.Lignes.Count * EspaceEntreSystemes + 80;

}

private void DessinerBarreDouble(Canvas canvas, double x, double yTop)
{
    // Barre fine
    canvas.Children.Add(new Line
    {
        X1 = x,
        Y1 = yTop,
        X2 = x,
        Y2 = yTop + 40,
        Stroke = Brushes.Black,
        StrokeThickness = 1
    });

    // Barre épaisse juste à droite
    canvas.Children.Add(new Line
    {
        X1 = x + 4,
        Y1 = yTop,
        X2 = x + 4,
        Y2 = yTop + 40,
        Stroke = Brushes.Black,
        StrokeThickness = 3
    });
}

public void SurbrillanceNote(Canvas canvas, NoteVisualisee note, double x, double y)
{
    Rectangle highlight = new Rectangle
    {
        Width = GetNoteWidth(note.Duree) + 8,
        Height = 18,
        Fill = Brushes.Orange,
        Opacity = 0.5,
        RadiusX = 4,
        RadiusY = 4
    };

    Canvas.SetLeft(highlight, x - 4);
    Canvas.SetTop(highlight, y - 4);
    canvas.Children.Add(highlight);
}

private void DessinerSignatureRythmique(Canvas canvas, double yBaseSol, double yBaseFa)
{
    double xSignature = 50; // Position ajustée pour se placer juste après la clé

    // Récupération de la police depuis les ressources
    var fontInter = Application.Current.Resources["FontInter"] as FontFamily ?? new FontFamily("Segoe UI");

    // Signature pour la clé de Sol en noir
    var signatureSol = new TextBlock
    {
        Text = "4\n4",
        FontSize = 18,
        FontWeight = FontWeights.Bold,
        FontFamily = fontInter,
        Foreground = Brushes.Black, // Toujours noir
        TextAlignment = TextAlignment.Center,
        LineHeight = 16
    };
    Canvas.SetLeft(signatureSol, xSignature);
    Canvas.SetTop(signatureSol, yBaseSol - 12);
    canvas.Children.Add(signatureSol);

    // Signature pour la clé de Fa en noir
    var signatureFa = new TextBlock
    {
        Text = "4\n4",
        FontSize = 18,
        FontWeight = FontWeights.Bold,
        FontFamily = fontInter,
        Foreground = Brushes.Black, // Toujours noir
        TextAlignment = TextAlignment.Center,
        LineHeight = 16
    };
    Canvas.SetLeft(signatureFa, xSignature);
    Canvas.SetTop(signatureFa, yBaseFa - 12);
    canvas.Children.Add(signatureFa);
}

private double ConvertirNoteEnYClassique(NoteVisualisee note, double yBaseSol, double yBaseFa)
{
    bool isCleFa = note.IsCleFa;
    double yBase = isCleFa ? yBaseFa : yBaseSol;

    int index = GetStaffIndex(note, isCleFa);

    double y = yBase - index * StepPx;

    Console.WriteLine($"🎯 Y calculé: {y} pour Index: {index}, CleFa: {isCleFa}");
    return y;
}

private int GetStaffIndex(NoteVisualisee note, bool isCleFa)
{
    int[] diatonicOffsets = { 0, 1, 2, 3, 4, 5, 6 };

    int baseIndex;
    int octaveBase;

    if (isCleFa)
    {
        baseIndex = 4;   // Fa
        octaveBase = 4;  // Fa3
    }
    else
    {
        baseIndex = 9;   // Sol
        octaveBase = 9;  // Sol4
    }

    int octaveOffset = note.Hauteur switch
    {
        PlageHauteur.Grave => -1,
        PlageHauteur.Moyen => 0,
        PlageHauteur.Aigu => +1,
        _ => 0
    };

    int noteIndex = (octaveBase + octaveOffset) * 7 + diatonicOffsets[note.Pas];
    int referenceIndex = (octaveBase * 7) + baseIndex;
    int staffIndex = noteIndex - referenceIndex;

    Console.WriteLine($"🎯 Cle: {(isCleFa ? "Fa" : "Sol")}, Note: {note.Pas}, Hauteur: {note.Hauteur}, StaffIndex: {staffIndex}");

    return staffIndex;
}


        #region Dessin des portées et clés

private void DessinerPortee(Canvas canvas, double yBase)
{
    for (int i = 0; i < 5; i++)
    {
        canvas.Children.Add(new Line
        {
            X1 = 0,
            Y1 = yBase + i * LineSpacing,
            X2 = 2000,
            Y2 = yBase + i * LineSpacing,
            Stroke = Brushes.Black,
            StrokeThickness = 1
        });
    }

    // Ajoute un debug visuel simple :
    Console.WriteLine($"🎯 Portée dessinée à partir de y={yBase}");
}


        private void DessinerCleSol(Canvas canvas, double yTop)
        {
            // Affiche l’image de clé de sol
            var clefSol = new Image
            {
                Width = 40,
                Height = 80,
                Source = new BitmapImage(new Uri("pack://application:,,,/Images/clef.png"))
            };
            Canvas.SetLeft(clefSol, 10);
            Canvas.SetTop(clefSol, yTop);
            canvas.Children.Add(clefSol);
        }

        private void DessinerCleFa(Canvas canvas, double yTop)
        {
            // Affiche l’image de clé de fa
            var clefFa = new Image
            {
                Width = 40,
                Height = 80,
                Source = new BitmapImage(new Uri("pack://application:,,,/Images/clef_fa.png"))
            };
            Canvas.SetLeft(clefFa, 10);
            Canvas.SetTop(clefFa, yTop);
            canvas.Children.Add(clefFa);
        }

        private void DessinerAccolade(Canvas canvas, double ySol, double yFa)
        {
            // Barre verticale reliant les deux portées
            canvas.Children.Add(new Line
            {
                X1 = 5,
                Y1 = ySol - 10,
                X2 = 5,
                Y2 = yFa + 50,
                Stroke = Brushes.Black,
                StrokeThickness = 2
            });
        }

        #endregion

        #region Dessin des notes et silences

        private void DessinerNote(Canvas canvas, double x, double y, NoteVisualisee note)
        {
            // Dessiner l’ellipse de la note
            Ellipse ellipse = new Ellipse
            {
                Width  = GetNoteWidth(note.Duree),
                Height = NoteHeight,
                Fill   = (note.Duree == DureeNote.Blanche || note.Duree == DureeNote.Ronde)
                        ? Brushes.White
                        : Brushes.Black,
                Stroke = Brushes.Black,
                StrokeThickness = (note.Duree == DureeNote.Blanche || note.Duree == DureeNote.Ronde) ? 1 : 0
            };

            Canvas.SetLeft(ellipse, x);
            Canvas.SetTop(ellipse, y);
            canvas.Children.Add(ellipse);

            // Si ce n’est pas une ronde, on dessine la hampe
            if (note.Duree != DureeNote.Ronde)
            {
                canvas.Children.Add(new Line
                {
                    X1 = x + ellipse.Width,
                    Y1 = y,
                    X2 = x + ellipse.Width,
                    Y2 = y - 30,
                    Stroke = Brushes.Black,
                    StrokeThickness = 1
                });
            }

            // Si croche ou double croche, dessiner le crochet
            if (note.Duree == DureeNote.Croche || note.Duree == DureeNote.DoubleCroche)
            {
                var fig = new PathFigure { StartPoint = new Point(x + ellipse.Width, y - 30) };
                fig.Segments.Add(new BezierSegment(
                    new Point(x + ellipse.Width + 5, y - 35),
                    new Point(x + ellipse.Width + 5, y - 15),
                    new Point(x + ellipse.Width,     y - 10),
                    isStroked: true));

                if (note.Duree == DureeNote.DoubleCroche)
                {
                    fig.Segments.Add(new BezierSegment(
                        new Point(x + ellipse.Width + 5, y - 25),
                        new Point(x + ellipse.Width + 5, y - 5),
                        new Point(x + ellipse.Width,     y),
                        isStroked: true));
                }

                var path = new Path
                {
                    Stroke = Brushes.Black,
                    StrokeThickness = 1,
                    Data = new PathGeometry { Figures = new PathFigureCollection { fig } }
                };
                canvas.Children.Add(path);
            }

            // Gérer d’éventuelles lignes supplémentaires si la note est trop haute/basse
            AjouterLignesSupplementaires(canvas, x, y);
        }

private void DessinerSilence(Canvas canvas, double x, double y, DureeNote duree, bool isClefFa)
{
    TextBlock silenceText = new TextBlock { FontSize = 40 };

    // Choisir le symbole en fonction de la durée
    string symbole = duree switch
    {
        DureeNote.Ronde        => "𝄻",
        DureeNote.Blanche      => "𝄼",
        DureeNote.Noire        => "𝄽",
        DureeNote.Croche       => "𝄾",
        DureeNote.DoubleCroche => "𝄿",
        _                      => "𝄽"
    };

    silenceText.Text = symbole;

    double offset = 0;
    // Ajuster l'offset en fonction du type de silence
    switch (duree)
    {
        case DureeNote.Ronde:
            offset = isClefFa ? -20 : -40;
            break;
        case DureeNote.Blanche:
            offset = isClefFa ? -20 : -40;
            break;
        case DureeNote.Noire:
            offset = isClefFa ? -30 : -56; // Celui-ci est déjà correct
            break;
     
    }

    Canvas.SetLeft(silenceText, x);
    Canvas.SetTop(silenceText, y + offset);
    canvas.Children.Add(silenceText);
}




        #endregion

        #region Barres de mesure et lignes supplémentaires

        private void DessinerBarreDeMesure(Canvas canvas, double x, double yTop)
        {
            // Trace une barre verticale
            canvas.Children.Add(new Line
            {
                X1 = x,
                Y1 = yTop,
                X2 = x,
                Y2 = yTop + 40,
                Stroke = Brushes.Black,
                StrokeThickness = 1
            });
        }

        private void AjouterLignesSupplementaires(Canvas canvas, double x, double y)
        {
            // Exemple simplifié : si la note dépasse un certain range, tracer des lignes
            // A adapter selon votre échelle
            double minY = TopOffset - 4 * LineSpacing;
            double maxY = TopOffset + 60 + 4 * LineSpacing;

            if (y < minY || y > maxY)
            {
                // On peut tracer les barres "ledger lines" 
                // (ex. tous les 2 * LineSpacing en haut ou en bas).
                // ...
            }
        }

        #endregion

    

        /// <summary>
        /// Détermine la largeur (en pixels) d’une note selon sa durée (ronde, blanche…).
        /// </summary>
        private double GetNoteWidth(DureeNote duree)
        {
            return duree switch
            {
                DureeNote.Ronde        => 20,
                DureeNote.Blanche      => 20,
                DureeNote.Noire        => 10,
                DureeNote.Croche       => 8,
                DureeNote.DoubleCroche => 6,
                _                      => 10
            };
        }


   
        /// <summary>
        /// Affiche un entête sur la partition (titre + compositeur),
        /// si IsForExport == true.
        /// </summary>
         public void AfficherEntete(Canvas canvas, string titre, string compositeur)
        {
           
        }

    }
}

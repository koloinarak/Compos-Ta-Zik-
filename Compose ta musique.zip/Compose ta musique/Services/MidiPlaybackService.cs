using NAudio.Midi;

namespace ComposTaZik.Services
{
    public class MidiPlaybackService
    {
        private MidiOut midiOut;

        public MidiPlaybackService()
        {
            midiOut = new MidiOut(0);
        }

        public void PlayNote(int noteNumber, int durationMs)
        {
            midiOut.Send(MidiMessage.StartNote(noteNumber, 127, 1).RawData);
            Task.Delay(durationMs).Wait();
            midiOut.Send(MidiMessage.StopNote(noteNumber, 0, 1).RawData);
        }

        public void Dispose() => midiOut.Dispose();
    }
}


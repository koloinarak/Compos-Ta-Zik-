// Version refondue de PartitionConstructionService.cs compatible avec MesuresSol / MesuresFa + support du chargement JSON
using System.Collections.Generic;
using ComposTaZik.Models;
using ComposTaZik.ViewModels;
using System.Linq;

namespace ComposTaZik.Services.Partition
{
    public class PartitionConstructionService
    {
        private readonly int _nbMesuresParLigne;
        private readonly double _tempsParMesure;
        private readonly PartitionMusicale _partition;

        public PartitionConstructionService(int nbMesuresParLigne, double tempsParMesure)
        {
            _nbMesuresParLigne = nbMesuresParLigne;
            _tempsParMesure = tempsParMesure;
            _partition = new PartitionMusicale();
            _partition.Lignes.Add(new LignePartition());
        }

        public PartitionMusicale GetPartition() => _partition;

        public void Reinitialiser()
        {
            _partition.Lignes.Clear();
            _partition.Lignes.Add(new LignePartition());
        }

        public void AjouterNote(PlageHauteur hauteur, int pas, DureeNote duree, bool isCleFa, bool isSilence = false)
        {
            double dureeTemps = GetValeurTemps(duree);

            var ligne = _partition.Lignes.LastOrDefault();
            if (ligne == null)
            {
                ligne = new LignePartition();
                _partition.Lignes.Add(ligne);
            }

            List<MesureVisualisee> mesures = isCleFa ? ligne.MesuresFa : ligne.MesuresSol;

            MesureVisualisee? mesureCible = mesures.FirstOrDefault(m => m.DureeTotale + dureeTemps <= _tempsParMesure);

            if (mesureCible == null)
            {
                ligne = new LignePartition();
                _partition.Lignes.Add(ligne);
                mesures = isCleFa ? ligne.MesuresFa : ligne.MesuresSol;
                mesureCible = mesures[0];
            }

            var note = new NoteVisualisee
            {
                Hauteur = hauteur,
                Pas = pas,
                Duree = duree,
                IsSilence = isSilence,
                IsCleFa = isCleFa
            };

            mesureCible.Notes.Add(note);
            mesureCible.DureeTotale += dureeTemps;
        }

        public void AjouterSilence(DureeNote duree, bool isCleFa)
        {
            AjouterNote(PlageHauteur.Moyen, 0, duree, isCleFa, isSilence: true);
        }

        public void ChargerPartition(PartitionSauvegardee partitionSauvegardee)
        {
            Reinitialiser();

            foreach (var note in partitionSauvegardee.Notes)
            {
                AjouterNote(note.Hauteur, note.Pas, note.Duree, note.IsCleFa, note.IsSilence);
            }
        }

        private double GetValeurTemps(DureeNote duree)
        {
            return duree switch
            {
                DureeNote.Ronde => 4.0,
                DureeNote.Blanche => 2.0,
                DureeNote.Noire => 1.0,
                DureeNote.Croche => 0.5,
                DureeNote.DoubleCroche => 0.25,
                _ => 1.0
            };
        }
    }
}

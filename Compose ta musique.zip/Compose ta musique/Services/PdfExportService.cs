using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using System;
using System.IO;

namespace ComposTaZik.Services
{
    public class PdfExportService
    {
        public void ExportTextToPdf(string filePath, string text)
        {
            QuestPDF.Settings.License = LicenseType.Community;

            var document = Document.Create(container =>
            {
                container.Page(page =>
                {
                    page.Size(PageSizes.A4);
                    page.Margin(2, Unit.Centimetre);
                    page.DefaultTextStyle(x => x.FontSize(20));

                    page.Header().Text("Partition export�e").Bold().FontSize(28).AlignCenter();
                    page.Content().Text(text).FontSize(20);
                    page.Footer().AlignRight().Text("Compos Ta Zik �").Italic();
                });
            });

            using var stream = File.Create(filePath);
            document.GeneratePdf(stream);
        }

        public void ExportCanvasToPdf(string filePath, string imagePath, string titre, string compositeur)
        {
            QuestPDF.Settings.License = LicenseType.Community;

            var document = Document.Create(container =>
            {
                container.Page(page =>
                {
                    page.Size(PageSizes.A4);
                    page.Margin(1, Unit.Centimetre);
                    page.DefaultTextStyle(x => x.FontSize(18));

                    // ?? En-t�te : Titre + Compositeur
                    page.Header().Element(header =>
                    {
                        header.Column(col =>
                        {
                            col.Item().Text(titre).Bold().FontSize(24).AlignCenter();
                            col.Item().Text($"Par {compositeur}").Italic().FontSize(14).FontColor(Colors.Grey.Darken2).AlignCenter();
                        });
                    });

                    // ??? Partition
                    page.Content().Image(imagePath).FitWidth();

                    // ?? Footer : date d�export
                    page.Footer().AlignRight().Text($"G�n�r� le {DateTime.Now:dd/MM/yyyy HH:mm}");
                });
            });

            using var stream = File.Create(filePath);
            document.GeneratePdf(stream);
        }
    }
}


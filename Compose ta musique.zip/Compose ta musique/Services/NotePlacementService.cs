using ComposTaZik.Models;
using ComposTaZik.ViewModels;
using System;

namespace ComposTaZik.Services
{
    public class NotePlacementService
    {
        private int currentX = 60;
        private const int XStep = 30;
        private const int MesuresParLigne = 4;

        private int notesParMesure = 4;
        private int compteurMesure = 0;
        private int ligneActuelle = 0;

        public int CurrentX => currentX;
        public int LigneActuelle => ligneActuelle;

        public NoteVisualisee AjouterNote(PlageHauteur hauteur, int pas, DureeNote duree)
        {
            var note = new NoteVisualisee
            {
                X = currentX,
                Hauteur = hauteur,
                Pas = pas,
                Duree = duree,
                Ligne = ligneActuelle,
                Nom = $"Note_{currentX}"
            };

            compteurMesure++;

            if (compteurMesure >= notesParMesure * MesuresParLigne)
            {
                DescendreLigne();
            }

            return note;
        }

        public void AvancerX() => currentX += XStep;

        public void DescendreLigne()
        {
            ligneActuelle++;
            currentX = 60;
            compteurMesure = 0;
        }

        public void Reinitialiser()
        {
            currentX = 60;
            ligneActuelle = 0;
            compteurMesure = 0;
        }
    }
}


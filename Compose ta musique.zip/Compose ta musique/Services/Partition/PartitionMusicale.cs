using System.Collections.Generic;
using System.Linq;
using ComposTaZik.Models;

namespace ComposTaZik.Services.Partition
{
    public class PartitionMusicale
    {
        public List<LignePartition> Lignes { get; set; } = new();

        /// <summary>
        /// Permet de parcourir toutes les notes de la partition (Sol + Fa).
        /// </summary>
        public IEnumerable<NoteVisualisee> AllNotes =>
            Lignes.SelectMany(l =>
                l.MesuresSol.Concat(l.MesuresFa)
            ).SelectMany(m => m.Notes);
    }
}

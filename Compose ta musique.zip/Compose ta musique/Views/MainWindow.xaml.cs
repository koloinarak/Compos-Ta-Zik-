using ComposTaZik.ViewModels;
using ComposTaZik.Views;
using System;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Runtime.InteropServices;
using System.Windows.Interop;

namespace ComposTaZik
{
    public partial class MainWindow : Window
    {
        private readonly MainViewModel viewModel;

      public MainWindow()
{
           // ConsoleManager.AllocConsole(); // ✅ Ouverture de console pour affichage debug

            InitializeComponent();
    viewModel = new MainViewModel();
    DataContext = viewModel;

    Loaded += (s, e) =>
    {
        viewModel.SetCanvas(PartitionCanvas);
        ExportPdfButton.Click += ExportPdfButton_Click;
        VoirPartitionsButton.Click += VoirPartitionsButton_Click;
    };
}



        private void VoirPartitionsButton_Click(object sender, RoutedEventArgs e)
        {
            var fenetre = new VoirPartitionsWindow();
            bool? result = fenetre.ShowDialog();

            if (result == true && fenetre.PartitionSelectionnee is not null)
            {
                viewModel.ChargerDepuisObjet(fenetre.PartitionSelectionnee);
            }
        }

        private void ExportPdfButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "Fichier PDF (*.pdf)|*.pdf",
                FileName = "partition.pdf",
                Title = "Enregistrer la partition"
            };

            if (dialog.ShowDialog() == true)
            {
                var size = new Size(PartitionCanvas.ActualWidth, PartitionCanvas.ActualHeight);
                PartitionCanvas.Measure(size);
                PartitionCanvas.Arrange(new Rect(size));

                var rtb = new RenderTargetBitmap((int)size.Width, (int)size.Height, 96, 96, PixelFormats.Pbgra32);
                rtb.Render(PartitionCanvas);

                string imagePath = Path.Combine(Path.GetTempPath(), "partition_temp.png");

                var encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(rtb));
                using (var fs = new FileStream(imagePath, FileMode.Create))
                    encoder.Save(fs);

                viewModel.ExportCanvasImageToPdf(imagePath, dialog.FileName);
                MessageBox.Show("PDF export� avec succ�s !", "Export PDF", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        internal static class ConsoleManager
{
    [DllImport("kernel32.dll")]
    public static extern bool AllocConsole();
}

    }
}


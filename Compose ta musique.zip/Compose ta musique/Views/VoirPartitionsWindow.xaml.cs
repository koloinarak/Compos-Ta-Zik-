using ComposTaZik.Models;
using ComposTaZik.ViewModels;
using System.Windows;

namespace ComposTaZik.Views
{
    public partial class VoirPartitionsWindow : Window
    {
        public PartitionSauvegardee? PartitionSelectionnee { get; private set; }

        public VoirPartitionsWindow()
        {
            InitializeComponent();
            DataContext = new VoirPartitionsViewModel();
        }

        private void ChargerPartition_Click(object sender, RoutedEventArgs e)
        {
            if (PartitionsListBox.SelectedItem is PartitionEntity selected)
            {
                var viewModel = (VoirPartitionsViewModel)DataContext;
                var partition = viewModel.GetSauvegardeeFromEntity(selected);

                if (partition != null)
                {
                    PartitionSelectionnee = partition;
                    DialogResult = true;
                    Close();
                }
                else
                {
                    MessageBox.Show("Erreur lors du chargement de la partition.", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner une partition.", "Alerte", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void SupprimerPartition_Click(object sender, RoutedEventArgs e)
        {
            if (PartitionsListBox.SelectedItem is PartitionEntity selected)
            {
                var confirm = MessageBox.Show(
                    $"Supprimer la partition '{selected.Titre}' ?",
                    "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                if (confirm == MessageBoxResult.Yes)
                {
                    var viewModel = (VoirPartitionsViewModel)DataContext;
                    viewModel.SupprimerPartition(selected);
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner une partition à supprimer.", "Alerte", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}


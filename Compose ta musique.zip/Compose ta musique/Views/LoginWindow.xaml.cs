using ComposTaZik.ViewModels;
using ComposTaZik.Models;
using System.Windows;

namespace ComposTaZik.Views
{
    public partial class LoginWindow : Window
    {
        private readonly LoginViewModel viewModel;

        public LoginWindow()
        {
            InitializeComponent();
            viewModel = new LoginViewModel();
            viewModel.OnLoginResult += HandleLoginResult;
            DataContext = viewModel;
        }

        private void HandleLoginResult(LoginResult result)
        {
            if (result.IsSuccess)
            {
                new MainWindow().Show();
                Close();
            }
            else
            {
                MessageBox.Show(result.Message, "Erreur", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (DataContext is LoginViewModel vm)
                vm.MotDePasse = PasswordBox.Password;
        }
    }
}


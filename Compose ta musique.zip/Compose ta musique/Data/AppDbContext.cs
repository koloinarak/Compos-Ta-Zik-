using Microsoft.EntityFrameworkCore;
using ComposTaZik.Models;

namespace ComposTaZik.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Utilisateur> Utilisateurs { get; set; }
        public DbSet<PartitionEntity> Partitions { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=ComposTaZik.db");
        }
    }
}


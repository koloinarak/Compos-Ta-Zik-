using ComposTaZik.Data;
using ComposTaZik.Models;
using System.Linq;

namespace ComposTaZik
{
    public static class TestSeeder
    {
        public static void Seed()
        {
            using var db = new AppDbContext();
            if (!db.Utilisateurs.Any())
            {
                db.Utilisateurs.Add(new Utilisateur
                {
                    Nom = "Admin",
                    Email = "test@zik.com",
                    MotDePasse = "1234",
                    Role = "Admin"
                });
                db.SaveChanges();
            }
        }
    }
}


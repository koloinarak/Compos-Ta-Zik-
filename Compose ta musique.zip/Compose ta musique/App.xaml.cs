using System.Windows;
using ComposTaZik.Views;
using QuestPDF; // Ajoutez cet espace de noms si ce n'est pas d�j� fait

namespace ComposTaZik
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            QuestPDF.Settings.License = QuestPDF.Infrastructure.LicenseType.Community; // Ajout ici

            TestSeeder.Seed(); // ? c�est ici que tu l�appelles

            var loginWindow = new LoginWindow();
            loginWindow.Show();
        }
    }
}


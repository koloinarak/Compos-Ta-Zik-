using System;
using System.Collections.Generic;
using System.Linq;
using ComposTaZik.Models;

namespace ComposTaZik.Helpers
{
    public static class MidiTimelineHelper
    {
        public static List<List<NoteVisualisee>> ConstruireTimeline(List<NoteVisualisee> sol, List<NoteVisualisee> fa)
        {
            // On fusionne les deux portées
            var toutes = sol.Concat(fa)
                            .OrderBy(n => n.PositionX)
                            .ToList();

            // On regroupe les notes superposées (~ même moment) par PositionX arrondie
            var groupes = toutes
                .GroupBy(n => Math.Round(n.PositionX, 2))
                .OrderBy(g => g.Key)
                .Select(g => g.ToList())
                .ToList();

            return groupes;
        }
    }
}

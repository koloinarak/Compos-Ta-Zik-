using ComposTaZik.Models;
using ComposTaZik.ViewModels;

namespace ComposTaZik.Services.Partition
{
    public static class NoteHelper
    {
        public const int DO4 = 60;

        private static readonly int[] DiatonicToSemitone = { 0, 2, 4, 5, 7, 9, 11 };

        public static int GetMidi(NoteVisualisee note)
        {
            int baseDo = PlageHauteurMidi.GetBaseDo(note.Hauteur);
            int pasOffset = DiatonicToSemitone[note.Pas];
            return baseDo + pasOffset;
        }

        public static Cle DetecterClePourMidi(int midi)
        {
            if (midi >= 29 && midi <= 57) return Cle.Fa;    // Fa1 → La3
            if (midi >= 62 && midi <= 91) return Cle.Sol;   // Ré4 → Sol6
            return Cle.Sol;
        }

        public static bool NoteEstDansBonneCle(NoteVisualisee note, Cle cle)
        {
            int midi = GetMidi(note);
            var cleAttendue = DetecterClePourMidi(midi);
            return cleAttendue == cle;
        }
    }

    public static class PlageHauteurMidi
    {
        public static int GetBaseDo(PlageHauteur hauteur)
        {
            return hauteur switch
            {
                PlageHauteur.Grave => 36, // Do2
                PlageHauteur.Moyen => 60, // Do4
                PlageHauteur.Aigu  => 72, // Do5
                _ => 60
            };
        }
    }
}

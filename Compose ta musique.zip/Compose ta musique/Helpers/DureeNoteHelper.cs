using System;
using System.Collections.Generic;
using System.Linq;
using ComposTaZik.Models;
using ComposTaZik.ViewModels;


namespace ComposTaZik.Helpers
{

public static class DureeNoteHelper
{
    public static DureeNote[] ToutesLesValeurs => (DureeNote[])Enum.GetValues(typeof(DureeNote));
}

}


using System;
using System.Collections.Generic;
using System.Linq;
using ComposTaZik.Models;
using ComposTaZik.ViewModels;


namespace ComposTaZik.Helpers
{
    public static class PlageHauteurHelper
{
    public static PlageHauteur[] ToutesLesValeurs => (PlageHauteur[])Enum.GetValues(typeof(PlageHauteur));
}

}

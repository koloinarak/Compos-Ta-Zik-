using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ComposTaZik.Migrations
{
    /// <inheritdoc />
    public partial class FixPartitionStrings : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CheminFichier",
                table: "Partitions",
                type: "TEXT",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CheminFichier",
                table: "Partitions");
        }
    }
}


# Nettoyage des fichiers et dossiers générés automatiquement

Write-Host "🔄 Nettoyage du projet en cours..."

# Supprime tous les dossiers 'bin' et 'obj' récursivement
Get-ChildItem -Path "." -Include "bin", "obj" -Recurse -Directory | ForEach-Object {
    Write-Host "🗑️ Suppression de $($_.FullName)"
    Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
}

# Supprime tous les fichiers *.wpftmp.*
Get-ChildItem -Path "." -Recurse -Include "*wpftmp.*" | ForEach-Object {
    Write-Host "🗑️ Suppression du fichier temporaire $($_.FullName)"
    Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue
}

Write-Host "✅ Nettoyage terminé ! Tu peux recompiler ton projet."

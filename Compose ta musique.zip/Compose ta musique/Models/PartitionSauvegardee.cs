using System.Collections.Generic;
using ComposTaZik.ViewModels;

namespace ComposTaZik.Models
{
    public class PartitionSauvegardee
    {
        public string Titre { get; set; } = string.Empty;
        public string Compositeur { get; set; } = string.Empty;

        // On stocke la liste de NoteVisualisee
        public List<NoteVisualisee> Notes { get; set; } = new();
    }
}

using ComposTaZik.ViewModels;

namespace ComposTaZik.Models
{
    public class NoteVisualisee
    {
        public double X { get; set; }
        public int Pas { get; set; }  // 0=Do,1=Ré,...,6=Si
        public PlageHauteur Hauteur { get; set; } = PlageHauteur.Moyen;
        public DureeNote Duree { get; set; } = DureeNote.Noire;
        
        // Indique si cette "note" est en réalité un silence
        public bool IsSilence { get; set; } = false;

        // Indique si la note se trouve en clé de fa (true) ou sol (false)
        public bool IsCleFa { get; set; } = false;

        // Facultatif : Nom, Ligne, etc.
        public string Nom { get; set; } = string.Empty;
        public int Ligne { get; set; } = 0;
        public double PositionX { get; set; }
    }
}

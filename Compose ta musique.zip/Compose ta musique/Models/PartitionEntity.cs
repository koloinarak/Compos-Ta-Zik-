using System.ComponentModel.DataAnnotations;

namespace ComposTaZik.Models
{
    public class PartitionEntity
{
    public int Id { get; set; }
    public string Titre { get; set; } = string.Empty;
    public string Compositeur { get; set; } = string.Empty;
    public string CheminFichier { get; set; } = string.Empty;
    public string JsonContenu { get; set; } = string.Empty;
    public DateTime DateCreation { get; set; }

    public override string ToString()
    {
        return $"{Titre} - {Compositeur}";
    }
}


}


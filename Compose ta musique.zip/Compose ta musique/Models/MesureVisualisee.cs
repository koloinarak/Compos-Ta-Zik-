using System.Collections.Generic;

namespace ComposTaZik.Models
{
    public class MesureVisualisee
    {
        /// <summary>
        /// Liste des notes contenues dans la mesure
        /// </summary>
        public List<NoteVisualisee> Notes { get; set; } = new();

        /// <summary>
        /// Durée totale en temps de la mesure (max = 4 pour une mesure 4/4)
        /// </summary>
        public double DureeTotale { get; set; } = 0;
    }
}


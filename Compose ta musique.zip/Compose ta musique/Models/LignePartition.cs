using System.Collections.Generic;

namespace ComposTaZik.Models
{
    public class LignePartition
    {
        public List<MesureVisualisee> MesuresSol { get; set; } = new();
        public List<MesureVisualisee> MesuresFa  { get; set; } = new();

        public LignePartition()
        {
            for (int i = 0; i < 4; i++)
            {
                MesuresSol.Add(new MesureVisualisee());
                MesuresFa.Add(new MesureVisualisee());
            }
        }
    }
}

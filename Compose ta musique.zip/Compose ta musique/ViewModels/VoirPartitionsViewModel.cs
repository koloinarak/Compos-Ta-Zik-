using ComposTaZik.Data;
using ComposTaZik.Models;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text.Json;

namespace ComposTaZik.ViewModels
{
    public class VoirPartitionsViewModel
    {
        public ObservableCollection<PartitionEntity> Partitions { get; set; }

        public VoirPartitionsViewModel()
        {
            Partitions = new ObservableCollection<PartitionEntity>();
            ChargerDepuisLaBase();
        }

        private void ChargerDepuisLaBase()
        {
            using var db = new AppDbContext();
            var partitionsEnBase = db.Partitions
                .OrderByDescending(p => p.DateCreation)
                .ToList();

            foreach (var p in partitionsEnBase)
                Partitions.Add(p);
        }

        public PartitionSauvegardee? GetSauvegardeeFromEntity(PartitionEntity entity)
        {
            try
            {
                return JsonSerializer.Deserialize<PartitionSauvegardee>(entity.JsonContenu);
            }
            catch
            {
                return null;
            }
        }

        public void SupprimerPartition(PartitionEntity entity)
        {
            using var db = new AppDbContext();
            var item = db.Partitions.FirstOrDefault(p => p.Id == entity.Id);

            if (item != null)
            {
                db.Partitions.Remove(item);
                db.SaveChanges();
                Partitions.Remove(entity);
            }
        }
    }
}


using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes; // ✅ Ajout nécessaire
using ComposTaZik.Models;
using ComposTaZik.Services;
using ComposTaZik.Services.Partition;
using ComposTaZik.Helpers;
using System.Runtime.InteropServices;
using ComposTaZik.Enums;



namespace ComposTaZik.ViewModels
{
    public partial class MainViewModel : ObservableObject
    {
        // ----------------------------------------------------------------
        // Propriétés bindables : Titre, Compositeur, StatusMessage, etc.
        // ----------------------------------------------------------------
[DllImport("kernel32.dll")]
static extern bool AllocConsole();
[ObservableProperty]
private ModeAjout modeAjoutSelectionne = ModeAjout.Normal;
partial void OnModeAjoutSelectionneChanged(ModeAjout value)
{
    if (value == ModeAjout.Superpose)
    {
        var partition = _constructionService.GetPartition();
        var ligne = partition.Lignes.ElementAtOrDefault(_indexLigneCourante);

        if (ligne == null) return;

        var mesures = CleSelectionnee == Cle.Fa ? ligne.MesuresFa : ligne.MesuresSol;
        var indexMesure = CleSelectionnee == Cle.Fa ? _indexMesureFa : _indexMesureSol;

        var mesure = mesures.ElementAtOrDefault(indexMesure);

        if (mesure != null)
        {
            // 💡 Comme en mode normal : base + offset selon le nombre de notes déjà présentes
            double baseX = 60 + indexMesure * 150;
            double offsetX = mesure.Notes.Count(n => !n.IsSilence) * (GetNoteWidth(DureeSelectionnee) + 10);
            _xCourantSuperpose = baseX + offsetX;
        }
        else
        {
            _xCourantSuperpose = 60 + indexMesure * 150;
        }
    }
}


public IEnumerable<ModeAjout> TousLesModesAjout => Enum.GetValues(typeof(ModeAjout)).Cast<ModeAjout>();



        [ObservableProperty]
        private string titre = string.Empty;

        [ObservableProperty]
        private string compositeur = string.Empty;

        [ObservableProperty]
        private string statusMessage = "Prêt à composer ?";

        // Durée sélectionnée (noire, croche, etc.)
        [ObservableProperty]
        private DureeNote dureeSelectionnee = DureeNote.Noire;

        // Hauteur (grave, moyen, aigu)
        [ObservableProperty]
        private PlageHauteur hauteurSelectionnee = PlageHauteur.Moyen;

        // Choix de la clé (Sol ou Fa) pour l'ajout de note
        [ObservableProperty]
        private Cle cleSelectionnee = Cle.Sol;  // Par défaut : clé de sol

        // Liste pour le ComboBox
        public IEnumerable<Cle> ToutesLesCles { get; } = new[] { Cle.Sol, Cle.Fa };

// ----------------------------------------------------------------
// Services et champs privés
// ----------------------------------------------------------------

private readonly MidiPlaybackService _midiService = new();
private readonly PdfExportService _pdfService = new();
private readonly PartitionCanvasRenderer _canvasRenderer = new();
private readonly PartitionConstructionService _constructionService;

// ↓↓↓ Champs inutilisés pour le moment ↓↓↓
 private double _xCourant = 60;
private const double _deltaX = 30;
private double _xCourantSuperpose = 60; // utilisé pour le mode Superpose

// private int _indexMesureCourante = 0;
private int _indexLigneCourante = 0;
private const double MaxTempsParMesure = 4.0;
private const int NbMesuresParLigne = 4;
private int _indexMesureSol = 0;
private int _indexMesureFa = 0;

private double _tempsDansMesure = 0;
private double _tempsDansMesureSol = 0;
private double _tempsDansMesureFa = 0;

// private double _dernierXSuperposition = 0;

private Canvas? _partitionCanvas;

public enum ModeLecture
{
    CleSol,
    CleFa,
    Simultane
}

[ObservableProperty]
private ModeLecture modeLectureSelectionne = ModeLecture.Simultane;
public IEnumerable<ModeLecture> TousLesModesLecture => Enum.GetValues(typeof(ModeLecture)).Cast<ModeLecture>();

        // ----------------------------------------------------------------
        // Constructeur
        // ----------------------------------------------------------------
        public MainViewModel()
        {
            // 5 mesures par ligne, 4 temps (4/4)
            _constructionService = new PartitionConstructionService(5, 4.0);
        }

        // ----------------------------------------------------------------
        // Liaison au Canvas pour le dessin
        // ----------------------------------------------------------------
      public void SetCanvas(Canvas canvas)
{
    _partitionCanvas = canvas;
    RedessinerPartition();

    // Ajoute la ligne de lecture
    if (_ligneDeLecture == null)
    {
        var ligneLecture = new Line
        {
            X1 = 60,
            Y1 = 0,
            X2 = 60,
            Y2 = canvas.Height,
            Stroke = Brushes.Red,
            StrokeThickness = 2,
            Visibility = Visibility.Hidden
        };

        canvas.Children.Add(ligneLecture);
        _ligneDeLecture = ligneLecture;
    }
}
        private Line? _ligneDeLecture;
        private double _dernierXSuperposition = 60;
        // ----------------------------------------------------------------
        // Redessiner la partition (double portée : Sol + Fa)
        // ----------------------------------------------------------------
        private void RedessinerPartition()
        {
            if (_partitionCanvas == null) return;

            var partition = _constructionService.GetPartition();
            _canvasRenderer.DessinerPartitionDoublePortee(_partitionCanvas, partition);
        }

private void AvancerDansPartition()
{
    double duree = GetValeurTemps(DureeSelectionnee);

    if (CleSelectionnee == Cle.Sol)
    {
        _tempsDansMesureSol += duree;
        if (_tempsDansMesureSol >= MaxTempsParMesure)
        {
            _tempsDansMesureSol = 0;
            _indexMesureSol++;
            if (_indexMesureSol >= NbMesuresParLigne)
            {
                _indexMesureSol = 0;
                _indexLigneCourante++;
            }
        }
    }
    else
    {
        _tempsDansMesureFa += duree;
        if (_tempsDansMesureFa >= MaxTempsParMesure)
        {
            _tempsDansMesureFa = 0;
            _indexMesureFa++;
            if (_indexMesureFa >= NbMesuresParLigne)
            {
                _indexMesureFa = 0;
                _indexLigneCourante++;
            }
        }
    }
}



        // ----------------------------------------------------------------
        // Méthodes pour ajouter des notes (commande RelayCommand)
        // ----------------------------------------------------------------

        // Méthode générique pour ajouter une note
   private double GetValeurTemps(DureeNote duree)
{
    return duree switch
    {
        DureeNote.Ronde => 4.0,
        DureeNote.Blanche => 2.0,
        DureeNote.Noire => 1.0,
        DureeNote.Croche => 0.5,
        DureeNote.DoubleCroche => 0.25,
        _ => 1.0
    };
}

private void AjouterNote(int pas)
{
    var note = new NoteVisualisee
    {
        Hauteur   = HauteurSelectionnee,
        Pas       = pas,
        Duree     = DureeSelectionnee,
        IsSilence = false,
        IsCleFa   = (CleSelectionnee == Cle.Fa)
    };

    AjouterEntiteMusicale(note);
}




[RelayCommand]
private void TerminerAccord()
{
    if (ModeAjoutSelectionne == ModeAjout.Superpose)
    {
        var partition = _constructionService.GetPartition();
        var ligne = partition.Lignes[_indexLigneCourante];

        // ➕ Ajouter 1 fois la durée de l’accord à la bonne mesure
        double duree = GetValeurTemps(DureeSelectionnee);

        if (CleSelectionnee == Cle.Fa)
        {
            var mesureFa = ligne.MesuresFa[_indexMesureFa];
            mesureFa.DureeTotale += duree;

            if (mesureFa.DureeTotale >= MaxTempsParMesure)
            {
                AvancerDansPartition();
            }
        }
        else
        {
            var mesureSol = ligne.MesuresSol[_indexMesureSol];
            mesureSol.DureeTotale += duree;

            if (mesureSol.DureeTotale >= MaxTempsParMesure)
            {
                AvancerDansPartition();
            }
        }

        _xCourantSuperpose += 30; // Préparer visuellement la prochaine position X
        StatusMessage = "✅ Accord terminé, prêt pour le suivant.";
    }
    else
    {
        StatusMessage = "ℹ️ Tu n'es pas en mode Superpose.";
    }
}



        [RelayCommand]
        private void AjouterNoteDo() => AjouterNote(0);

        [RelayCommand]
        private void AjouterNoteRe() => AjouterNote(1);

        [RelayCommand]
        private void AjouterNoteMi() => AjouterNote(2);

        [RelayCommand]
        private void AjouterNoteFa() => AjouterNote(3);

        [RelayCommand]
        private void AjouterNoteSol() => AjouterNote(4);

        [RelayCommand]
        private void AjouterNoteLa() => AjouterNote(5);

        [RelayCommand]
        private void AjouterNoteSi() => AjouterNote(6);


// ----------------------------------------------------------------
// Méthodes pour ajouter des silences (corrigées avec clé correcte)
// ----------------------------------------------------------------

private void AjouterSilencePourCle(DureeNote duree)
{
    var silence = new NoteVisualisee
    {
        Duree     = duree,
        IsSilence = true,
        IsCleFa   = (CleSelectionnee == Cle.Fa)
    };

    AjouterEntiteMusicale(silence);
}




private void AjouterEntiteMusicale(NoteVisualisee entite)
{
    var partition = _constructionService.GetPartition();

    // Étendre les lignes si nécessaire
    while (partition.Lignes.Count <= _indexLigneCourante)
        partition.Lignes.Add(new LignePartition());

    var ligne = partition.Lignes[_indexLigneCourante];
    var mesures = entite.IsCleFa ? ligne.MesuresFa : ligne.MesuresSol;
    int indexMesure = entite.IsCleFa ? _indexMesureFa : _indexMesureSol;

    // Étendre les mesures si nécessaire
    while (mesures.Count <= indexMesure)
        mesures.Add(new MesureVisualisee());

    var mesure = mesures[indexMesure];
    double duree = GetValeurTemps(entite.Duree);

    // Vérifie s’il y a assez de place
    if (mesure.DureeTotale + duree > MaxTempsParMesure)
    {
        // Avancer à la mesure/ligne suivante
        if (entite.IsCleFa)
        {
            _tempsDansMesureFa = 0;
            _indexMesureFa++;
            if (_indexMesureFa >= NbMesuresParLigne)
            {
                _indexMesureFa = 0;
                _indexLigneCourante++;
            }
        }
        else
        {
            _tempsDansMesureSol = 0;
            _indexMesureSol++;
            if (_indexMesureSol >= NbMesuresParLigne)
            {
                _indexMesureSol = 0;
                _indexLigneCourante++;
            }
        }

        // Re-tenter l’ajout dans la nouvelle mesure
        AjouterEntiteMusicale(entite);
        return;
    }

    // Position X
    double baseX = 60 + indexMesure * 150;
    double offsetX = mesure.Notes.Count(n => !n.IsSilence) * (GetNoteWidth(entite.Duree) + 10);
    double nextX = baseX + offsetX;

    if (ModeAjoutSelectionne == ModeAjout.Superpose && !entite.IsSilence)
    {
        // Superposer à la dernière position connue
        entite.PositionX = _xCourantSuperpose;
    }
    else
    {
        entite.PositionX = nextX;
        _xCourantSuperpose = nextX; // On prépare la prochaine superposition ici
    }

    // Vérifie doublon si ce n’est pas un silence
    bool existeDeja = !entite.IsSilence && mesure.Notes.Any(n =>
        n.Pas == entite.Pas &&
        n.Hauteur == entite.Hauteur &&
        n.IsCleFa == entite.IsCleFa &&
        Math.Abs(n.PositionX - entite.PositionX) < 0.01);

    if (!existeDeja || entite.IsSilence)
    {
        mesure.Notes.Add(entite);

        // On augmente la durée uniquement si ce n’est pas en superposition OU que c’est un silence
        if (ModeAjoutSelectionne != ModeAjout.Superpose || entite.IsSilence)
        {
            mesure.DureeTotale += duree;
        }

        // En mode normal, on avance automatiquement
        if (ModeAjoutSelectionne == ModeAjout.Normal && !entite.IsSilence)
            AvancerDansPartition();

        RedessinerPartition();

        StatusMessage = entite.IsSilence
            ? $"🤫 Silence {entite.Duree} ajouté."
            : $"🎵 {(ModeAjoutSelectionne == ModeAjout.Superpose ? "Note superposée" : "Note ajoutée")}.";

    }
    else
    {
        StatusMessage = "❌ Note déjà présente ou mesure pleine.";
    }
}




[RelayCommand] private void AjouterSilenceRonde()        => AjouterSilencePourCle(DureeNote.Ronde);
[RelayCommand] private void AjouterSilenceBlanche()      => AjouterSilencePourCle(DureeNote.Blanche);
[RelayCommand] private void AjouterSilenceNoire()        => AjouterSilencePourCle(DureeNote.Noire);
[RelayCommand] private void AjouterSilenceCroche()       => AjouterSilencePourCle(DureeNote.Croche);
[RelayCommand] private void AjouterSilenceDoubleCroche() => AjouterSilencePourCle(DureeNote.DoubleCroche);

private void DeplacerCurseurLecture(double x)
{
    if (_ligneDeLecture != null)
    {
        Application.Current.Dispatcher.Invoke(() =>
        {
            _ligneDeLecture.X1 = x;
            _ligneDeLecture.X2 = x;
            _ligneDeLecture.Visibility = Visibility.Visible;
        });
    }
}

private void CacherCurseurLecture()
{
    if (_ligneDeLecture != null)
    {
        Application.Current.Dispatcher.Invoke(() =>
        {
            _ligneDeLecture.Visibility = Visibility.Hidden;
        });
    }
}

private double GetNoteWidth(DureeNote duree)
{
    return duree switch
    {
        DureeNote.Ronde => 30,
        DureeNote.Blanche => 25,
        DureeNote.Noire => 20,
        DureeNote.Croche => 15,
        DureeNote.DoubleCroche => 10,
        _ => 20
    };
}

        // ----------------------------------------------------------------
        // Réinitialiser la partition
        // ----------------------------------------------------------------
    
[RelayCommand]
private void Reinitialiser()
{
    _constructionService.Reinitialiser();

    _xCourant = 60;
    _xCourantSuperpose = 60;

    _indexLigneCourante = 0;
    _indexMesureSol = 0;
    _indexMesureFa = 0;

    _tempsDansMesure = 0;
    _tempsDansMesureSol = 0;
    _tempsDansMesureFa = 0;

    RedessinerPartition();
    StatusMessage = "🎼 Partition réinitialisée avec succès.";
}


        // ----------------------------------------------------------------
        // Lecture MIDI (ignorer les silences)
        // ----------------------------------------------------------------
   [RelayCommand]
private async Task LectureMidi()
{
    var partition = _constructionService.GetPartition();

    foreach (var ligne in partition.Lignes)
    {
        for (int i = 0; i < 4; i++)
        {
            var sol = ligne.MesuresSol.ElementAtOrDefault(i)?.Notes ?? new List<NoteVisualisee>();
            var fa = ligne.MesuresFa.ElementAtOrDefault(i)?.Notes ?? new List<NoteVisualisee>();

            List<List<NoteVisualisee>> timeline = ModeLectureSelectionne switch
            {
                ModeLecture.CleSol     => MidiTimelineHelper.ConstruireTimeline(sol, new()),
                ModeLecture.CleFa      => MidiTimelineHelper.ConstruireTimeline(new(), fa),
                ModeLecture.Simultane  => MidiTimelineHelper.ConstruireTimeline(sol, fa),
                _ => new()
            };

            double x = 60 + i * 150;

            foreach (var moment in timeline)
            {
                DeplacerCurseurLecture(x);

                await Task.WhenAll(moment
                    .Where(n => !n.IsSilence)
                    .Select(note =>
                    {
                        int midiNote = CalculerNoteMidi(note);
                        int dureeMs = DureeNoteVersMs(note.Duree);
                        return Task.Run(() => _midiService.PlayNote(midiNote, dureeMs));
                    }));

                int maxDuree = moment.Select(n => DureeNoteVersMs(n.Duree)).DefaultIfEmpty(500).Max();
                await Task.Delay(maxDuree);

             x += 10 + moment.Select(n => GetNoteWidth(n.Duree)).DefaultIfEmpty(10).Max();

            }
        }
    }

    CacherCurseurLecture();
    StatusMessage = "🎶 Lecture terminée.";
}

private void LireMoment(List<NoteVisualisee> moment)
{
    foreach (var note in moment)
    {
        if (!note.IsSilence)
        {
            int midiNote = CalculerNoteMidi(note);
            int dureeMs = DureeNoteVersMs(note.Duree);

            // Lecture sans délai via Task.Run pour éviter le décalage
            Task.Run(() => _midiService.PlayNote(midiNote, dureeMs));
        }
    }
}

private void LireNoteAsync(NoteVisualisee note)
{
    if (note.IsSilence) return;

    int midiNote = CalculerNoteMidi(note);
    int dureeMs = DureeNoteVersMs(note.Duree);

    _midiService.PlayNote(midiNote, dureeMs);
}

private int DureeNoteVersMs(DureeNote duree)
{
    // Valeurs en millisecondes (modifiable selon tes préférences de tempo)
    int tempoMsParTemps = 500; // 1 temps = 500 ms (tempo environ 120 BPM)

    return duree switch
    {
        DureeNote.Ronde => tempoMsParTemps * 4,         // 4 temps
        DureeNote.Blanche => tempoMsParTemps * 2,       // 2 temps
        DureeNote.Noire => tempoMsParTemps,             // 1 temps
        DureeNote.Croche => tempoMsParTemps / 2,        // 0.5 temps
        DureeNote.DoubleCroche => tempoMsParTemps / 4,  // 0.25 temps
        _ => tempoMsParTemps
    };
}


        // ----------------------------------------------------------------
        // Calcul de la note MIDI
        // ----------------------------------------------------------------
       private int CalculerNoteMidi(NoteVisualisee note)
{
    int octaveBaseMidi;

    if (note.IsCleFa)
    {
        octaveBaseMidi = note.Hauteur switch
        {
            PlageHauteur.Grave => 29,   // Fa1
            PlageHauteur.Moyen => 41,   // Fa2
            PlageHauteur.Aigu  => 53,   // Fa3
            _ => 41
        };
    }
    else
    {
        octaveBaseMidi = note.Hauteur switch
        {
            PlageHauteur.Grave => 48,   // Do3
            PlageHauteur.Moyen => 60,   // Do4
            PlageHauteur.Aigu  => 72,   // Do5
            _ => 60
        };
    }

    int pasOffset = note.Pas switch
    {
        0 => 0,  // Do
        1 => 2,  // Ré
        2 => 4,  // Mi
        3 => 5,  // Fa
        4 => 7,  // Sol
        5 => 9,  // La
        6 => 11, // Si
        _ => 0
    };

    return octaveBaseMidi + pasOffset;
}

        // ----------------------------------------------------------------
        // Sauvegarder en JSON
        // ----------------------------------------------------------------
        [RelayCommand]
 private void Sauvegarder()
{
    var partition = _constructionService.GetPartition();

    // Création de l'objet à sauvegarder
    var partitionSauvegardee = new PartitionSauvegardee
    {
        Titre = Titre,
        Compositeur = Compositeur,
        Notes = new List<NoteVisualisee>()
    };

    // Copie des notes actuelles dans l'objet de sauvegarde
    foreach (var note in partition.AllNotes)
    {
        partitionSauvegardee.Notes.Add(new NoteVisualisee
        {
            Hauteur   = note.Hauteur,
            Pas       = note.Pas,
            Duree     = note.Duree,
            IsSilence = note.IsSilence,
            IsCleFa   = note.IsCleFa
        });
    }

    var dialog = new SaveFileDialog
    {
        Filter = "Fichier JSON (*.json)|*.json",
        FileName = string.IsNullOrWhiteSpace(Titre) ? "Partition" : Titre + ".json"
    };

    if (dialog.ShowDialog() == true)
    {
        try
        {
            var options = new JsonSerializerOptions { WriteIndented = true };
            var json = JsonSerializer.Serialize(partitionSauvegardee, options);

            File.WriteAllText(dialog.FileName, json);
            StatusMessage = "✔️ Partition sauvegardée avec succès.";
        }
        catch (Exception ex)
        {
            StatusMessage = $"❌ Erreur lors de la sauvegarde : {ex.Message}";
        }
    }
}

        // ----------------------------------------------------------------
        // Charger un JSON
        // ----------------------------------------------------------------
        [RelayCommand]
        private void Charger()
        {
            var dialog = new OpenFileDialog { Filter = "Fichier JSON (*.json)|*.json" };
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    var json = File.ReadAllText(dialog.FileName);
                    var partitionSauvegardee = JsonSerializer.Deserialize<PartitionSauvegardee>(json);
                    if (partitionSauvegardee != null)
                    {
                        Titre = partitionSauvegardee.Titre;
                        Compositeur = partitionSauvegardee.Compositeur;

                        _constructionService.ChargerPartition(partitionSauvegardee);
                        RedessinerPartition();

                        StatusMessage = "Partition chargée.";
                    }
                }
                catch (Exception ex)
                {
                    StatusMessage = "Erreur de chargement : " + ex.Message;
                }
            }
        }

        // ----------------------------------------------------------------
        // ChargerDepuisObjet : si on veut charger depuis un objet en mémoire
        // ----------------------------------------------------------------
        public void ChargerDepuisObjet(PartitionSauvegardee partition)
        {
            Titre = partition.Titre;
            Compositeur = partition.Compositeur;

            _constructionService.ChargerPartition(partition);
            RedessinerPartition();

            StatusMessage = $"Partition '{partition.Titre}' chargée !";
        }

        // ----------------------------------------------------------------
        // Export PDF (après capture d’écran du Canvas, par exemple)
        // ----------------------------------------------------------------
        public void ExportCanvasImageToPdf(string imagePath, string outputPath)
        {
            _pdfService.ExportCanvasToPdf(outputPath, imagePath, Titre, Compositeur);
        }
    }
}

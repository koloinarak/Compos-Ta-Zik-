namespace ComposTaZik.ViewModels
{
    public enum Cle
    {
        Sol,
        Fa
    }
}

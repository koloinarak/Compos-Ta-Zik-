using System;
using System.Collections.Generic;
using System.Linq;

namespace ComposTaZik.Models
{
    public enum DureeNote
    {
        Ronde,
        Blanche,
        Noire,
        Croche,
        DoubleCroche
    }

    public static class DureeNoteHelper
    {
        public static IEnumerable<DureeNote> ToutesLesValeurs => Enum.GetValues(typeof(DureeNote)).Cast<DureeNote>();
    }
}


namespace ComposTaZik.Enums
{
    public enum ModeAjout
    {
        Normal,
        Superpose
    }
}

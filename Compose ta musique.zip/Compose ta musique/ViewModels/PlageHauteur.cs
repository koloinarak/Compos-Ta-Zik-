namespace ComposTaZik.ViewModels
{
    public enum PlageHauteur
    {
        Grave,
        Moyen,
        Aigu
    }

    public static class PlageHauteurHelper
    {
        public static Array GetValues => Enum.GetValues(typeof(PlageHauteur));
    }
}


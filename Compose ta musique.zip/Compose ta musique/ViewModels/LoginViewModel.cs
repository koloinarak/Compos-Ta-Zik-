using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using ComposTaZik.Models;
using ComposTaZik.Data;
using System;
using System.Linq;

namespace ComposTaZik.ViewModels
{
    public partial class LoginViewModel : ObservableObject
    {
        [ObservableProperty] private string email = string.Empty;
        [ObservableProperty] private string motDePasse = string.Empty;
        [ObservableProperty] private string message = string.Empty;

        public event Action<LoginResult>? OnLoginResult;

        [RelayCommand]
        private void Login()
        {
            using var db = new AppDbContext();
            var utilisateur = db.Utilisateurs
                .FirstOrDefault(u => u.Email == Email && u.MotDePasse == MotDePasse);

            if (utilisateur != null)
            {
                OnLoginResult?.Invoke(new LoginResult
                {
                    IsSuccess = true,
                    Message = "Connexion réussie !"
                });
            }
            else
            {
                Message = "Identifiants incorrects.";
                OnLoginResult?.Invoke(new LoginResult
                {
                    IsSuccess = false,
                    Message = "Erreur de connexion."
                });
            }
        }
    }
}

